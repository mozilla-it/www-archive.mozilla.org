/**
 * FileName: parbanner.java
 * 
 * The contents of this file are subject to the Mozilla Public
 * License Version 1.1 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a copy of
 * the License at http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS
 * IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
 * implied. See the License for the specific language governing
 * rights and limitations under the License.
 *
 * The Original Code is Mozilla Communicator Test Cases.
 *
 * The Initial Developer of the Original Code is Netscape Communications
 * Corp.  Portions created by Netscape Communications Corp. are
 * Copyright (C) 1999 Netscape Communications Corp.  All
 * Rights Reserved.
 * 
 * Contributor(s): Prashant Desale <desale@netscape.com>
 *                 
 * This is a scrolloing meesage applet with parameter taking as input.               
 * 
 * 
 *
 * revision history
 * 27.March.2000 - modified, Prashant Desale <desale@netscape.com>              
 * 
 */

import java.awt.*;
import java.applet.*;
public class parbanner extends Applet implements Runnable{
	String msg, bgvalue, fgvalue;
	Thread t = null;
	Color bgcolor;
	Color fgcolor;
	public void init(){
		bgvalue = getParameter("bgcolor");
                if (bgvalue != null)
	        {
		        bgcolor = new Color(Integer.parseInt(bgvalue, 16));
                }
                else
                {
                	bgcolor = Color.white;
                }
		setBackground(bgcolor);

		fgvalue = getParameter("fgcolor");
		if (fgvalue != null)
	        {
		        fgcolor = new Color(Integer.parseInt(fgvalue, 16));
                }
                else
                {
                	fgcolor = Color.black;
                }

		setForeground(fgcolor);
		msg = getParameter("message");
		t = new Thread(this);
		t.start();
		t.suspend();
	}
	public void start(){
		            
		if (msg == null) {
		msg = "Message not found.";
		}
		msg = " " + msg;
		t.resume();
	}

	public void run(){
		char ch;

		for ( ; ; ){
			try{
				repaint();
				Thread.sleep(350);
				ch = msg.charAt(0);
				msg = msg.substring(1,msg.length());
				msg += ch;
			}
			catch(InterruptedException e){}
		}
	}
	public void stop(){
		t.suspend();
	}
	public void destroy(){
		if (t != null){
			t.stop();
			t = null;
		}
	}
	public void paint(Graphics g){
		g.setFont(new Font("Courier", Font.BOLD, 24));
		g.drawString(msg,0,30);
	}
}
