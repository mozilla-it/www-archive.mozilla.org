/**
 * FileName: applet2.java
 * 
 * The contents of this file are subject to the Mozilla Public
 * License Version 1.1 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a copy of
 * the License at http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS
 * IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
 * implied. See the License for the specific language governing
 * rights and limitations under the License.
 *
 * The Original Code is Mozilla Communicator Test Cases.
 *
 * The Initial Developer of the Original Code is Netscape Communications
 * Corp.  Portions created by Netscape Communications Corp. are
 * Copyright (C) 1999 Netscape Communications Corp.  All
 * Rights Reserved.
 * 
 * Contributor(s): Prashant Desale <desale@netscape.com>
 *                 
 * This is a applet to copy names from list.               
 * 
 * 
 *
 * revision history
 * 15.March.2000 - modified, Prashant Desale <desale@netscape.com>              
 * 
 */
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.Applet;

public class applet2 extends Applet implements ActionListener{

	Button add1;
	Button remove1;
	List firstlist, secondlist;
	Label prompt;


	public void init(){
		setBackground(Color.lightGray);
			
		prompt = new Label("Try  Shifting CIA team memeber Names from list to list                         ");
  		add(prompt);

		//Create First list from where you are going to add names to second list.
		firstlist = new List(7);
		add(firstlist);
		firstlist.add("Gerardo Kvaternik");
		firstlist.add("Chris Kritzer");
		firstlist.add("Jan Carpenter");
		firstlist.add("Prashant Desale");
		firstlist.add("Chris Dreckman");
		firstlist.add("Chris Petersen");
		firstlist.add("Robert Ginda");
		

		//Create Right Shift button.
		add1 = new Button("SHIFT  >>");
		add1.addActionListener(this);
		add(add1);
		//Create Left Shift button
		remove1 = new Button("SHIFT <<");
		remove1.addActionListener(this);
		add(remove1);

		//Create Second list where you want to add names.
		secondlist = new List(7);
		add(secondlist);
		
	}

	public void actionPerformed( ActionEvent e)
   	{
		if (e.getSource() == add1){
			secondlist.add(firstlist.getSelectedItem());
			firstlist.remove(firstlist.getSelectedItem());
		}
		if (e.getSource() == remove1){
			firstlist.add(secondlist.getSelectedItem());
			secondlist.remove(secondlist.getSelectedItem());
		}

	repaint();
   	}


}