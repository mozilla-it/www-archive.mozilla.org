/**
 * FileName: game.java
 * 
 * The contents of this file are subject to the Mozilla Public
 * License Version 1.1 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a copy of
 * the License at http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS
 * IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
 * implied. See the License for the specific language governing
 * rights and limitations under the License.
 *
 * The Original Code is Mozilla Communicator Test Cases.
 *
 * The Initial Developer of the Original Code is Netscape Communications
 * Corp.  Portions created by Netscape Communications Corp. are
 * Copyright (C) 1999 Netscape Communications Corp.  All
 * Rights Reserved.
 * 
 * Contributor(s): Prashant Desale <desale@netscape.com>
 *                 
 * This is a simple game applet where you need to catch color balls with box.               
 * 
 * 
 *
 * revision history
 * 15.March.2000 - modified, Prashant Desale <desale@netscape.com>              
 * 
 */
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.Applet;

public class game extends Applet implements ActionListener{

	
	Button hor, ver, hor1, ver1;
	Label prompt;
	int start1, start2, start3, start4, width1, height1, width2, height2, horinc, i;
	int tarh1, tarv1, tarh2, tarv2, tarh3, tarv3, tarh4, tarv4, tarh5, tarv5, tarh6, tarv6;

	public void init(){
		setBackground(Color.pink);
			
		prompt = new Label("         Try to Catch All Those Red Balls with The Bule Box.");
  		add(prompt);

		width1 = 10;
		height1 = 10;
		width2 = 8;
		height2 = 8;
		start1 = 0;
		start2 = 30;
		start3 = 2;
		start4 = 32;
		tarh1 = 100;
		tarv1 = 150;
		tarh2 = 210;
		tarv2 = 250;
		tarh3 = 150;
		tarv3 = 200;
		tarh4 = 200;
		tarv4 = 320;
		tarh5 = 220;
		tarv5 = 300;
		tarh6 = 50;
		tarv6 = 210;
		

		hor = new Button(" Move Horizontal Right ");
		add(hor);
		hor.addActionListener( this );

		hor1 = new Button(" Move Horizontal Left ");
		add(hor1);
		hor1.addActionListener( this );

		ver = new Button(" Move Vertical Down ");
		add(ver);
		ver.addActionListener( this );

		ver1 = new Button(" Move Vertical Up ");
		add(ver1);
		ver1.addActionListener( this );

		
	}
	public void paint(Graphics g){
		
			g.setFont(new Font("Courier", Font.BOLD, 12));
			g.setColor(Color.darkGray);
			g.fillRect(start1, start2, width1, height1);
			g.setColor(Color.blue);
			g.fillRect(start3, start4, width2, height2);

		if ((start1 == tarh1) && (start2 == tarv1)){
		g.setColor(Color.darkGray);
		g.drawString("You Catched Red Ball", tarh1, tarv1);
		}
		else{
		g.setColor(Color.red);
		g.fillOval(tarh1,tarv1,10,10);
		}

		if ((start1 == tarh2) && (start2 == tarv2)){
		g.setColor(Color.darkGray);
		g.drawString("You Catched Balck Ball", tarh2, tarv2);
		}
		else{
		g.setColor(Color.black);
		g.fillOval(tarh2,tarv2,10,10);
		}

		if ((start1 == tarh3) && (start2 == tarv3)){
		g.setColor(Color.darkGray);
		g.drawString("You Catched Green Ball", tarh3, tarv3);
		}
		else{
		g.setColor(Color.green);
		g.fillOval(tarh3,tarv3,10,10);
		}

		if ((start1 == tarh4) && (start2 == tarv4)){
		g.setColor(Color.darkGray);
		g.drawString("You Catched Gray Ball", tarh4, tarv4);
		}
		else{
		g.setColor(Color.gray);
		g.fillOval(tarh4,tarv4,10,10);
		}

		if ((start1 == tarh5) && (start2 == tarv5)){
		g.setColor(Color.darkGray);
		g.drawString("You Catched Cyan Ball", tarh5, tarv5);
		}
		else{
		g.setColor(Color.cyan);
		g.fillOval(tarh5,tarv5,10,10);
		}

		if ((start1 == tarh6) && (start2 == tarv6)){
		g.setColor(Color.darkGray);
		g.drawString("You Catched Magenta Ball", tarh6, tarv6);
		}
		else{
		g.setColor(Color.magenta);
		g.fillOval(tarh6,tarv6,10,10);
		}

		
	}

	public void actionPerformed( ActionEvent e)
   	{
		if (e.getSource() == hor){
			
			start1 = start1 + 10;
			start3 = start3 + 10;
		}
		if (e.getSource() == ver){
			start2 = start2 + 10;
			start4 = start4 + 10;
		}
		if (e.getSource() == hor1){
			
			start1 = start1 - 10;
			start3 = start3 - 10;
		}
		if (e.getSource() == ver1){
			start2 = start2 - 10;
			start4 = start4 - 10;
		}

	repaint();
   	}


}