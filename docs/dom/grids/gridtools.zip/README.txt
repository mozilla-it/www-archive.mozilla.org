Gridtools README

core_tab.html & html_tab.html
-----------------------------
These are the HTML documents in which the Core and HTML DOM Level 1 support matrices are presented. The various objects and their properties are listed in the left column, the results of the test related to that object or property for the various browsers and platforms make up the body of the matrix, and a link to the test is provided in the rightmost column.


gridtop.html & tabletext.html
-----------------------------
Boilerplate text that gets read in as the two files above are generated


core.csv & html.csv
-------------------
The source files for the data in the HTML documents. ADD NEW DATA TO THESE FILES


core.py & html.py
-----------------
Python scripts that generate the HTML pages from the source

