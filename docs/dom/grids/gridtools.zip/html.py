import string, sys

data = open('c:/Projects/web/html.csv').readlines()

w = open('html_tab.html', 'w')
gt = open('gridtop.html', 'r').read()
gb = open('tabletext.html', 'r').read()

w.write(gt)

# for core, this script should check for a dot in the name
# for html, it should check the initial capital letter

for item in data:
	s = string.strip(item)
	x = string.split(s, ',')
	lcol, x = x[0], x[1:]
	if string.capitalize(lcol[:1]) == lcol[:1]: w.write('<td class="rel">' + lcol + '</td>')
	else: w.write('<td class="par">' + lcol + '</td>')
	for i in x:
		w.write('<td class="' + i + '">' + i + '</td>') 
	
	w.write('</tr>\n')

w.write('</table>')
w.write(gb)
w.close()