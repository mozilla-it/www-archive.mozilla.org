About allxpstr_win32.txt
28 April 1998; R. Thorne, NSCP
==============================

The file allxpstr_win32.txt is a translation table for changes in resource IDs in the string table of resdll.dll between the 4.04 and 4.05 releases of Communicator and Navigator for Win32.  Since very few changes of resource ID occurred between the 4.03 and 4.04 versions, this file will be mostly valid for going between 4.03 and 4.05.

The major difference between 4.03 and 4.04 in this resource range is in the addition of some strings used by some of the security sub-systems that were changed in 4.04.  If you use this table to translate 4.03 resource IDs and 4.05 resource IDs, your leveraging tool will probably handle the new 4.05 strings correctly, although as always, we recommend checking carefully.

Format of the file:
-------------------

The file is tab-delimited, in the following format:

{Status}\t{XP Resource Name}\t{Resource ID in 4.04}\t{Resource ID in 4.05}\n

Where:
{Status} is either SAME (the ID did not change), MOVE (the ID changed), DELETE (the resource was in 4.04, but not in 4.05), or NEW_405 (not in 4.04, but new in 4.05).
{XP Resource Name} is the symbolic name we use in our headers.  This can be useful to you in understanding how the string is used.
{Resource ID in 4.04} is a resource name in the format used in the localization notes for 4.04.
{Resource ID in 4.05} is a resource name in localization note format for the 4.05 notes.

