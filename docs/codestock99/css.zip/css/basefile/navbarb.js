// navbar.js

// 28 July 1998
// All code has been removed from this file since there is no
// keyboard or click-on-image based navigation in the streaming
// audio version of the template.  This file has been left in
// for future expansion only in case we wish to add JavaScript
// to the control frame of the streaming audio version.