  function changeForeColor( obj, strcolor ) {
   obj.style.color = strcolor
  }

  function setLeft( obj, strleft) {
   obj.style.left = strleft
  }
