//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by XPIPackager.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_XPIPACKAGER_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDD_FILE_CHOOSER                129
#define IDR_HEADER                      132
#define IDR_BODY                        134
#define IDR_FILLER                      135
#define IDD_MIMETYPE_CHOOSER            136
#define IDC_AUTO_PLID                   1001
#define IDC_DOMAIN_NAME                 1002
#define IDC_PRODUCT_NAME                1003
#define IDC_PLUGIN_VERSION              1004
#define IDC_PLID_HELP                   1005
#define IDC_PLID                        1006
#define IDC_ARCHIVE_NAME                1007
#define IDC_PLUGIN_LIST                 1008
#define IDC_PLUGIN_BROWSE               1009
#define IDC_PLUGIN_REMOVE               1010
#define IDC_PLUGIN_SIZE                 1011
#define IDC_COMPONENT_LIST              1012
#define IDC_COMPONENT_BROWSE            1013
#define IDC_COMPONENT_REMOVE            1014
#define IDC_COMPONENT_SIZE              1015
#define IDC_MIME_LIST                   1016
#define IDC_COMPANY_NAME                1017
#define IDC_BIG_HELP                    1018
#define IDC_FILENAME_BROWSE             1019
#define IDC_FILENAME                    1020
#define IDC_PLUGIN_DESCRIPTION          1024
#define IDC_MIMETYPE_ADD                1025
#define IDC_MIMETYPE_REMOVE             1026
#define IDC_MIMETYPE                    1027
#define IDC_SUFFIX                      1028
#define IDC_SUFFIX_DESCRIPTION          1029

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1031
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
