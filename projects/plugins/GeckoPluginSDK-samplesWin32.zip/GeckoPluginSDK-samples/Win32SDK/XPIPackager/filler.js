var PLUGIN_FILE         = [%s];
var PLUGIN_FILE_PLID    = [%s];

var COMPONENT_FILE      = [%s];
var COMPONENT_FILE_PLID = [%s];

// (DLL files)
var PLUGIN_SIZE         = %d;

// (XPI files)
var COMPONENT_SIZE      = %d;

var SOFTWARE_NAME       = "%s";

var PLID    = "%s";

var VERSION = "%s";

var MIMETYPE           = [%s];
var SUFFIX             = [%s];
var SUFFIX_DESCRIPTION = [%s];
var COMPANY_NAME       = "%s";
var PLUGIN_DESCRIPTION = "%s";
