These are some of the Netscape tools and pre-built libraries needed to build Mozilla.
For up-to-date instructions on building Mozilla on Win32, see: http://www.mozilla.org/build/win32.html
Note: You'll see need to get cvs.exe or manually pull the source.

xpidl.exe that is included in the Gecko SDK may need the libIDL DLL in your path which can be found
in wintools\buildtools\windows\lib
