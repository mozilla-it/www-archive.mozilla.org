/*
 * CarDemo.java
 *
 * Created on March 3, 2007, 2:58 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package jsf_jmaki;

/**
 *
 * @author edburns
 */
public class JsfjMaki {
    
    /** Creates a new instance of CarDemo */
    public JsfjMaki() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
