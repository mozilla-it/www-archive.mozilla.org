/* -*- Mode: C++; tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 4 -*-
 *
 * The contents of this file are subject to the Mozilla Public
 * License Version 1.1 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a copy of
 * the License at http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS
 * IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
 * implied. See the License for the specific language governing
 * rights and limitations under the License.
 *
 * The Original Code is RaptorCanvas.
 *
 * The Initial Developer of the Original Code is Kirk Baker and
 * Ian Wilkinson. Portions created by Kirk Baker and Ian Wilkinson are
 * Copyright (C) 1999 Kirk Baker and Ian Wilkinson. All
 * Rights Reserved.
 *
 * Contributor(s):  Ashutosh Kulkarni <ashuk@eng.sun.com>
 *                  Ed Burns <edburns@acm.org>
 *
 */


package org.mozilla.webclient.wrapper_nonnative;

// ImplObjectNative.java

import org.mozilla.util.Assert;
import org.mozilla.util.Log;
import org.mozilla.util.ParameterCheck;

import org.mozilla.webclient.ImplObject;
import org.mozilla.webclient.WrapperFactory;
import org.mozilla.webclient.BrowserControl;
import org.mozilla.webclient.WindowControl;

public abstract class ImplObjectNonnative extends ImplObject
{

/**

 * My ivars are public for fast access from subclasses in the wrapper_*
 * packages.

 */


//
// Constructors and Initializers    
//

public ImplObjectNonnative(WrapperFactory yourFactory, 
			   BrowserControl yourBrowserControl)
{
    super(yourFactory, yourBrowserControl);
}


public ImplObjectNonnative(WrapperFactory yourFactory, 
			   BrowserControl yourBrowserControl,
			   boolean notUsed)
{
    super(yourFactory, yourBrowserControl);
}

public void delete()
{
    System.out.println("ImplObjectNative.delete()");
    super.delete();
}


} // end of class ImplObject
