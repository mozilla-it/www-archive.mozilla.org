package org.mozilla.webclient;

public interface DocListener {

    public void handleDocLoaderEvent();
    
}
