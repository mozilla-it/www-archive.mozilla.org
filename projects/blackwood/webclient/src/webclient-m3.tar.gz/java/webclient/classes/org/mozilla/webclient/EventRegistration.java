package org.mozilla.webclient;

public interface EventRegistration {

    public boolean addDocumentLoadListener(DocumentLoadListener dll) throws Exception;
    
    
}
