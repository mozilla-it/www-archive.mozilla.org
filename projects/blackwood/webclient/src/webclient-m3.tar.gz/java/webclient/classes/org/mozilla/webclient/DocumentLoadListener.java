package org.mozilla.webclient;

public interface DocumentLoadListener  {
    public void docEventPerformed(String event);

    
}
