/*
 * Pluglet.java
 *
 * Created on March 3, 2007, 2:58 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package pluglet;

/**
 *
 * @author edburns
 */
public class Pluglet {
    
    /** Creates a new instance of Pluglet */
    public Pluglet() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
