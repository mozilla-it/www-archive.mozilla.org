user_pref("plugin.allow_alien_star_handler", true);
user_pref("plugin.default_plugin_disabled", false);
user_pref("plugin.override_internal_types", true);

